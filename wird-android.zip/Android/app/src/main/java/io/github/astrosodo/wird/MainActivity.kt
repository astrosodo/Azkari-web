package io.github.astrosodo.wird

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {
    private val vm: WirdViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark by vm.dark.collectAsStateWithLifecycle()
            val isDark = dark ?: isSystemInDarkTheme()
            WirdTheme(isDark) {
                WirdRoot(vm, isDark)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshDay()
    }
}
