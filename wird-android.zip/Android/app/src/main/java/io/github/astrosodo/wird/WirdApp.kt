package io.github.astrosodo.wird

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Room

val Context.settingsStore by preferencesDataStore(name = "settings")

class WirdApp : Application() {
    val db: AppDb by lazy {
        Room.databaseBuilder(this, AppDb::class.java, "wird.db").build()
    }
}
