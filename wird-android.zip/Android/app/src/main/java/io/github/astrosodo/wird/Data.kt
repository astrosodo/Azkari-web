package io.github.astrosodo.wird

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "progress", primaryKeys = ["dhikrId", "day"])
data class ProgressEntity(val dhikrId: String, val day: String, val amount: Int)

@Entity(tableName = "day_stats")
data class DayStat(@PrimaryKey val day: String, val total: Int)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val dhikrId: String)

@Dao
abstract class AppDao {
    @Query("SELECT * FROM progress WHERE day = :day")
    abstract fun progress(day: String): Flow<List<ProgressEntity>>

    @Query("SELECT amount FROM progress WHERE dhikrId = :id AND day = :day")
    abstract suspend fun getAmount(id: String, day: String): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putProgress(p: ProgressEntity)

    @Query("SELECT total FROM day_stats WHERE day = :day")
    abstract suspend fun getTotal(day: String): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putStat(s: DayStat)

    @Query("SELECT * FROM day_stats WHERE day >= :from ORDER BY day")
    abstract fun statsFrom(from: String): Flow<List<DayStat>>

    @Query("SELECT * FROM favorites")
    abstract fun favorites(): Flow<List<FavoriteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun addFav(f: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE dhikrId = :id")
    abstract suspend fun removeFav(id: String)

    @Transaction
    open suspend fun change(id: String, day: String, delta: Int, max: Int) {
        val cur = getAmount(id, day) ?: 0
        val next = (cur + delta).coerceIn(0, max)
        val applied = next - cur
        if (applied == 0) return
        putProgress(ProgressEntity(id, day, next))
        val t = ((getTotal(day) ?: 0) + applied).coerceAtLeast(0)
        putStat(DayStat(day, t))
    }

    @Transaction
    open suspend fun reset(id: String, day: String) {
        val cur = getAmount(id, day) ?: 0
        if (cur > 0) change(id, day, -cur, Int.MAX_VALUE)
    }

    @Transaction
    open suspend fun addStat(day: String, delta: Int) {
        val t = ((getTotal(day) ?: 0) + delta).coerceAtLeast(0)
        putStat(DayStat(day, t))
    }
}

@Database(
    entities = [ProgressEntity::class, DayStat::class, FavoriteEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
}
