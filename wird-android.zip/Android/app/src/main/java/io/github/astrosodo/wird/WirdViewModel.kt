package io.github.astrosodo.wird

import android.app.Application
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class WirdViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = (app as WirdApp).db.dao()
    private val store = app.settingsStore

    private object K {
        val DARK = booleanPreferencesKey("dark")
        val TASBIH = intPreferencesKey("tasbih")
        val TARGET = intPreferencesKey("target")
    }

    private val day = MutableStateFlow(LocalDate.now().toString())

    fun refreshDay() {
        day.value = LocalDate.now().toString()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val progress: StateFlow<Map<String, Int>> = day
        .flatMapLatest { d -> dao.progress(d) }
        .map { list -> list.associate { it.dhikrId to it.amount } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val favorites: StateFlow<Set<String>> = dao.favorites()
        .map { list -> list.map { it.dhikrId }.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    @OptIn(ExperimentalCoroutinesApi::class)
    val week: StateFlow<List<Pair<String, Int>>> = day.flatMapLatest { d ->
        val start = LocalDate.parse(d).minusDays(6)
        dao.statsFrom(start.toString()).map { list ->
            val m = list.associate { it.day to it.total }
            (0..6).map { i ->
                val s = start.plusDays(i.toLong()).toString()
                s to (m[s] ?: 0)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val dark: StateFlow<Boolean?> = store.data.map { it[K.DARK] }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val tasbih: StateFlow<Int> = store.data.map { it[K.TASBIH] ?: 0 }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val target: StateFlow<Int> = store.data.map { it[K.TARGET] ?: 33 }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 33)

    fun change(d: Dhikr, delta: Int) {
        viewModelScope.launch { dao.change(d.id, day.value, delta, d.count) }
    }

    fun reset(d: Dhikr) {
        viewModelScope.launch { dao.reset(d.id, day.value) }
    }

    fun toggleFav(id: String, isFav: Boolean) {
        viewModelScope.launch {
            if (isFav) dao.removeFav(id) else dao.addFav(FavoriteEntity(id))
        }
    }

    fun setDark(value: Boolean) {
        viewModelScope.launch { store.edit { it[K.DARK] = value } }
    }

    fun tasbihTap() {
        viewModelScope.launch {
            store.edit { it[K.TASBIH] = (it[K.TASBIH] ?: 0) + 1 }
            dao.addStat(day.value, 1)
        }
    }

    fun tasbihUndo() {
        viewModelScope.launch {
            var changed = false
            store.edit {
                val c = it[K.TASBIH] ?: 0
                if (c > 0) {
                    it[K.TASBIH] = c - 1
                    changed = true
                }
            }
            if (changed) dao.addStat(day.value, -1)
        }
    }

    fun tasbihReset() {
        viewModelScope.launch { store.edit { it[K.TASBIH] = 0 } }
    }

    fun setTarget(value: Int) {
        viewModelScope.launch { store.edit { it[K.TARGET] = value } }
    }
}
