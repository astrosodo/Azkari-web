package io.github.astrosodo.wird

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.time.LocalDate
import java.time.format.TextStyle as JTextStyle
import java.util.Locale

private val LightColors = lightColorScheme(
    primary = Color(0xFF1B7F5C),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD4F1E4),
    onPrimaryContainer = Color(0xFF00382A),
    background = Color(0xFFF7FAF8),
    surface = Color(0xFFF7FAF8),
    surfaceVariant = Color(0xFFE9EFEB)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF6FD6AE),
    onPrimary = Color(0xFF00382A),
    primaryContainer = Color(0xFF0F4D3A),
    onPrimaryContainer = Color(0xFFD4F1E4),
    background = Color(0xFF0F1512),
    surface = Color(0xFF0F1512),
    surfaceVariant = Color(0xFF1C2622)
)

@Composable
fun WirdTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                content()
            }
        }
    }
}

private data class TabItem(val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem("الأذكار", Icons.Filled.Home),
    TabItem("بحث", Icons.Filled.Search),
    TabItem("المفضلة", Icons.Filled.Favorite),
    TabItem("السبحة", Icons.Filled.AddCircle),
    TabItem("إحصائيات", Icons.Filled.DateRange)
)

@Composable
fun WirdRoot(vm: WirdViewModel, isDark: Boolean) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var openCat by rememberSaveable { mutableStateOf<String?>(null) }

    BackHandler(enabled = openCat != null) { openCat = null }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = {
                            tab = i
                            openCat = null
                        },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(vm, isDark, openCat) { openCat = it }
                1 -> SearchScreen(vm)
                2 -> FavoritesScreen(vm)
                3 -> TasbihScreen(vm)
                else -> StatsScreen(vm)
            }
        }
    }
}

@Composable
fun Header(
    title: String,
    onBack: (() -> Unit)? = null,
    trailing: @Composable RowScope.() -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
            }
        } else {
            Spacer(Modifier.width(8.dp))
        }
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
        trailing()
    }
}

@Composable
fun HomeScreen(vm: WirdViewModel, isDark: Boolean, openCat: String?, onOpen: (String?) -> Unit) {
    val progress by vm.progress.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()

    if (openCat == null) {
        Column(Modifier.fillMaxSize()) {
            Header("وِرد | Wird") {
                Text("داكن", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.width(6.dp))
                Switch(checked = isDark, onCheckedChange = { vm.setDark(it) })
                Spacer(Modifier.width(8.dp))
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(Adhkar.categories, key = { it.id }) { c ->
                    val list = Adhkar.byCategory(c.id)
                    val done = list.count { (progress[it.id] ?: 0) >= it.count }
                    Card(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            Modifier.clickable { onOpen(c.id) }.padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(c.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(c.hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                "$done / ${list.size}",
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            Header(Adhkar.categoryTitle(openCat), onBack = { onOpen(null) })
            DhikrList(
                Adhkar.byCategory(openCat), progress, favs, vm,
                empty = "لا توجد أذكار", showCat = false, modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun DhikrList(
    list: List<Dhikr>,
    progress: Map<String, Int>,
    favs: Set<String>,
    vm: WirdViewModel,
    empty: String,
    showCat: Boolean,
    modifier: Modifier = Modifier
) {
    if (list.isEmpty()) {
        Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(empty, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(32.dp))
        }
        return
    }
    LazyColumn(modifier, contentPadding = PaddingValues(vertical = 8.dp)) {
        items(list, key = { it.id }) { d ->
            DhikrCard(
                d = d,
                done = progress[d.id] ?: 0,
                fav = d.id in favs,
                catTitle = if (showCat) Adhkar.categoryTitle(d.category) else null,
                vm = vm
            )
        }
    }
}

@Composable
fun DhikrCard(d: Dhikr, done: Int, fav: Boolean, catTitle: String?, vm: WirdViewModel) {
    val complete = done >= d.count
    val haptic = LocalHapticFeedback.current
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (complete) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            Modifier.clickable {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                vm.change(d, 1)
            }.padding(16.dp)
        ) {
            if (catTitle != null) {
                Text(catTitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(4.dp))
            }
            Text(d.text, fontSize = 20.sp, lineHeight = 36.sp)
            if (d.note.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(d.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        "${done.coerceAtMost(d.count)} / ${d.count}",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { vm.change(d, -1) }) { Text("تراجع") }
                TextButton(onClick = { vm.reset(d) }) { Text("إعادة") }
                IconButton(onClick = { vm.toggleFav(d.id, fav) }) {
                    Icon(
                        if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = "مفضلة",
                        tint = if (fav) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun SearchScreen(vm: WirdViewModel) {
    val progress by vm.progress.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    var q by rememberSaveable { mutableStateOf("") }
    val results = remember(q) {
        val n = Adhkar.normalize(q)
        if (n.isBlank()) emptyList() else Adhkar.all.filter { Adhkar.normalize(it.text).contains(n) }
    }
    Column(Modifier.fillMaxSize()) {
        Header("البحث")
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("ابحث في الأذكار…") },
            singleLine = true
        )
        DhikrList(
            results, progress, favs, vm,
            empty = if (q.isBlank()) "اكتب كلمة للبحث" else "لا توجد نتائج",
            showCat = true, modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun FavoritesScreen(vm: WirdViewModel) {
    val progress by vm.progress.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val list = Adhkar.all.filter { it.id in favs }
    Column(Modifier.fillMaxSize()) {
        Header("المفضلة")
        DhikrList(
            list, progress, favs, vm,
            empty = "لم تضف أي ذكر للمفضلة بعد.\nاضغط على القلب في أي ذكر.",
            showCat = true, modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun TasbihScreen(vm: WirdViewModel) {
    val count by vm.tasbih.collectAsStateWithLifecycle()
    val target by vm.target.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    val inRound = if (count == 0) 0 else ((count - 1) % target) + 1
    val rounds = count / target
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Header("السبحة الإلكترونية")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(33, 99, 100, 1000).forEach { t ->
                if (t == target) {
                    Button(onClick = { vm.setTarget(t) }) { Text("$t") }
                } else {
                    OutlinedButton(onClick = { vm.setTarget(t) }) { Text("$t") }
                }
            }
        }
        Spacer(Modifier.height(32.dp))
        Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { inRound / target.toFloat() },
                modifier = Modifier.fillMaxSize(),
                strokeWidth = 10.dp
            )
            Box(
                Modifier.size(230.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        vm.tasbihTap()
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "$count",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontSize = 56.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text("المرحلة: $inRound / $target", color = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("عدد الدورات المكتملة: $rounds", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { vm.tasbihUndo() }) { Text("تراجع") }
            OutlinedButton(onClick = { vm.tasbihReset() }) { Text("تصفير") }
        }
        Spacer(Modifier.height(24.dp))
    }
}

private fun dayLabel(date: String): String =
    LocalDate.parse(date).dayOfWeek.getDisplayName(JTextStyle.SHORT, Locale("ar"))

@Composable
fun StatsScreen(vm: WirdViewModel) {
    val week by vm.week.collectAsStateWithLifecycle()
    val today = week.lastOrNull()?.second ?: 0
    val total = week.sumOf { it.second }
    val max = (week.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("الإحصائيات")
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatBox("اليوم", today, Modifier.weight(1f))
            StatBox("آخر 7 أيام", total, Modifier.weight(1f))
        }
        Spacer(Modifier.height(24.dp))
        Text(
            "عدد التسبيحات والأذكار يوميًا",
            modifier = Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.titleSmall
        )
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth().height(200.dp).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            week.forEach { (d, v) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                    Text("$v", fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                    Box(
                        Modifier.width(26.dp)
                            .height(maxOf(3.dp, 130.dp * v / max))
                            .clip(RoundedCornerShape(5.dp))
                            .background(MaterialTheme.colorScheme.primary)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(dayLabel(d), fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun StatBox(label: String, value: Int, modifier: Modifier = Modifier) {
    Card(
        modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$value", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text(label, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
    }
}
