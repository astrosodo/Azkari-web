plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// نسخ ملفات الموقع من جذر المستودع إلى assets التطبيق أثناء البناء.
// المشروع يُفك في <المستودع>/wird-src/Android، لذلك جذر المستودع هو ../..
val siteDir = layout.buildDirectory.dir("site")

val syncSite = tasks.register<Copy>("syncSite") {
    from(rootDir.resolve("../.."))
    exclude(
        "Android/**", "wird-src/**", ".github/**", "github/**", ".git/**",
        "**/*.md", "**/*.zip", "**/*.apk", "LICENSE"
    )
    into(siteDir)
}

android {
    namespace = "io.github.astrosodo.wird"
    compileSdk = 34

    defaultConfig {
        applicationId = "io.github.astrosodo.wird"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    sourceSets.getByName("main").assets.srcDir(siteDir)
}

tasks.named("preBuild") {
    dependsOn(syncSite)
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
